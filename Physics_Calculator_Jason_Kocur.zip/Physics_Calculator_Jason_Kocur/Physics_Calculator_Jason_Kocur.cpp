#include <iostream>
#include <algorithm>
#include <string>
#include <cmath>
#include <iomanip>
#include <cstdlib>
#include "Input_Validation_Extended.h"
#include "Color_in_CPP.h"

using namespace std;

void showMenu();
void handleOption(string);
void motion(double,double,double,double);
double velocity(double,double);
double acceleration(double,double);
double newtonSecondLaw(double,double);
double weight(double);
double momentum(double, double);

int main()
{
	changeColor(11);
	string option = "";
	string choice = "";
	showMenu();
	cout << "Select an option(enter option in lowercase): ";
	do
	{
		getline(cin, option);
		handleOption(option);
		cout << "Would you like to see the menu again? (Y/N) ";
		choice = validateString(choice);
		if(choice == "Y" || choice == "y")
		{
			system("cls");
			showMenu();
			cout << "Select an option(enter option in lowercase): ";
		}
		else if(choice == "N" || choice =="n")
		{
			option = "e";
		}
	}while(option != "e" && option != "E");
	changeColor(7);
	return 0;
}

void handleOption(string userOption)
{
	transform(userOption.begin(),userOption.end(), userOption.begin(), ::tolower);
	if(userOption == "a")
	{
		double d1 = 0.0;
		double t1 = 0.0;
		string unit1 = "";
		string unit2 = "";
		cout << "What is dS: ";
		cin >> d1;
		cout << "What are the dS units: ";
		cin >> unit1;
		cout << "What is  dT: ";
		cin >> t1;
		cout << "What are the dT units: ";
		cin >> unit2;
		cout << velocity(d1,t1) <<" "<< unit1 <<"/"<< unit2 << endl;
		
	}
	else if(userOption == "b")
	{
		double d1 = 0.0;
		double t1 = 0.0;
		string unit1 = "";
		string unit2 = "";
		cout << "What is dV: ";
		cin >> d1;
		cout << "What are the dV units: ";
		cin >> unit1;
		cout << "What is  dT: ";
		cin >> t1;
		cout << "What are the dT units: ";
		cin >> unit2;
		cout << acceleration(d1,t1) <<" "<< unit1 <<"/"<< unit2 << "^2" << endl;
	}
	else if(userOption == "c")
	{
		double a = 0.0;
		double v0 = 0.0;
		double t = 0.0;
		double s0 = 0.0;
		cout << "What is v0: ";
		cin >> v0;
		cout << "What is a: ";
		cin >> a;
		cout << "What is t: ";
		cin >> t;
		cout << "What is s0: ";
		cin >> s0;
		
		motion(v0, a, t, s0);
	}
	else if(userOption == "d")
	{
		double m = 0.0;
		double a = 0.0;
		string unit1 = "";
		string unit2 = "";
		cout << "What is the value of M: ";
		cin >> m;
		cout << "What are the units of M: ";
		cin >> unit1;
		cout << "What is the value of A: ";
		cin >> a;
		cout << "What are the units of A: ";
		cin >> unit2;
		cout << newtonSecondLaw(m,a) << unit1 << "/" << unit2 << "^2" << endl;
	}
	else if(userOption == "e")
	{
		cout << "Goodbye." << endl;
	}
	else if(userOption == "f")
	{
		double m = 0.0;
		cout << "How much is the objects mass: ";
		cin >> m;
		cout << weight(m);
		
	}
	else if(userOption == "g")
	{
		double m = 0.0;
		double v = 0.0;
		cout << "What is the value of m: ";
		cin >> m;
		cout << "What is the value of v: ";
		cin >> v;
		cout << momentum(m,v);
	}
	else if(userOption == "x")
	{
		system("cls");
	}
	else
	{
		cout << "Error: SOMETHING WENT WRONG.";
	}
}

void showMenu()
{
	cout << "Option A: VELOCITY." << endl;
	cout << "Option B: ACCELERATION." << endl;
	cout << "Option C: MOTION Equations." << endl;
	cout << "Option D: NEWTON'S SECOND LAW." << endl;
	cout << "Option E: Exit the program." << endl;
	cout << "Option F: CALCULATION OF WEIGHT." << endl;
	cout << "Option G: MOMENTUM." << endl;
	cout << "Option X: Clear the screen." << endl;
}
double velocity(double ds,double dt)
{
	double v = 0.0;
	v= (ds)/(dt);
	cout << "The velocity is: ";
	return v;
}

double acceleration(double dv,double dt)
{
	double a = 0.0;
	a= (dv)/(dt);
	cout << "The acceleration is: ";
	return a;
}


void motion(double v0, double a, double t, double s0)
{
	double v = 0.0;
	v= v0 + (a*t);
	cout << "Ma is " << v << endl;
	double s = 0.0;
	s = s0 + (v0 * t) + (0.5 * a * t * t);
	cout << "Ms is " << s << endl;
	double v2 = 0.0;
	v2 = (v0 * v0) + 2 * a * (s - s0);
	cout << "Mv2 is " << v2 << endl;
	double vBar = 0.0;
	vBar = 0.5 * (v + v0);
	cout << "Mv is " << vBar << endl;
}

double newtonSecondLaw(double m, double a)
{
	double N = 0.0;
	N = m*a;
	cout << "N equals: " ;
	return N;
}

double weight(double m)
{
	double W = 0.0;
	double g = 9.8;
	W = m *g;
	cout << "The weight is: ";
	return W;
}

double momentum(double m, double v)
{
	double p = 0.0;
	p = m * v;
	cout << "The momentum is: ";
	return p;
}

